import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
   server: {
    proxy: {
      // 保留原有的/api前缀匹配（兼容验证码请求）
      '/api': {
        target: 'http://localhost:8083',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '')
      },
      // 新增：匹配/signup开头的请求，直接转发到后端（无需去掉前缀）
      '/signup': {
        target: 'http://localhost:8083',
        changeOrigin: true // 无需rewrite，因为前端路径和后端路径一致
      }
    },
    port: 5173,
    open: true,
    strictPort: true
  }
})