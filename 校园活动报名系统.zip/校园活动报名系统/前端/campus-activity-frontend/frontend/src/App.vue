<template>
  <router-view /> <!-- 报名页面会显示在这里 -->
</template>

<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
</style>