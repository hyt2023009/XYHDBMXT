import { createRouter, createWebHistory } from 'vue-router';
import Signup from '../views/Signup.vue'; // 导入报名页面

const routes = [
  { path: '/', component: Signup } // 根路径对应报名页面
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;