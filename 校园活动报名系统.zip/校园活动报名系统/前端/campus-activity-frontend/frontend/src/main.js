import { createApp } from 'vue'
import App from './App.vue'
import router from './router/index.js'
import axios from 'axios' // 引入Axios（需先安装：npm install axios）

// 配置Axios基础路径+拦截器
const service = axios.create({
  baseURL: '/api', // 与vite.config.js的代理路径对应
  timeout: 5000
})

// 请求拦截器（处理Token）
service.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// 响应拦截器（处理重试）
let retryCount = 0
service.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const config = error.config
    if (retryCount < 3 && error.response?.status !== 500) {
      retryCount++
      return new Promise((resolve) => {
        setTimeout(() => resolve(service(config)), 1000 * retryCount)
      })
    }
    retryCount = 0
    return Promise.reject(error)
  }
)

// 将Axios挂载到Vue实例，全局可用
const app = createApp(App)
app.config.globalProperties.$axios = service // 全局注册$axios
app.use(router).mount('#app')