<template>
  <div class="signup-container page-container">
    <h2>校园活动报名系统</h2>
    <!-- 报名表单 -->
    <form @submit.prevent="submitSignup" class="signup-form">
      <!-- 用户ID输入 -->
      <div class="form-item">
        <label>用户ID：</label>
        <input 
          type="number" 
          v-model="form.userId" 
          placeholder="请输入你的用户ID（如2025001）" 
          required
          @input="clearResult"
          :disabled="isSubmitting"
          class="form-input"
        >
      </div>
      <!-- 活动ID输入 + 活动列表弹窗触发 -->
      <div class="form-item">
        <label>活动ID：</label>
        <div class="activity-id-group">
          <input 
            type="number" 
            v-model="form.activityId" 
            placeholder="请输入活动ID或点击选择" 
            required
            @input="clearResult"
            :disabled="isSubmitting"
            @blur="checkActivityHotStatus"
            class="form-input"
          >
          <button 
            type="button" 
            class="select-activity-btn"
            @click="showActivityList = true"
            :disabled="isSubmitting"
          >
            选择活动
          </button>
        </div>
      </div>
      <!-- 学院ID输入 -->
      <div class="form-item">
        <label>学院ID：</label>
        <select 
          v-model="form.collegeId" 
          required
          @change="clearResult"
          :disabled="isSubmitting"
          class="form-select"
        >
          <option value="">请选择学院</option>
          <option value="1">计算机学院</option>
          <option value="2">商学院</option>
          <option value="3">文学院</option>
          <option value="4">外国语学院</option>
          <option value="5">艺术学院</option>
        </select>
      </div>
      <!-- 动态难度验证码（匹配文档防刷单要求） -->
      <div class="form-item captcha-group">
        <label>验证码：</label>
        <img 
          :src="captchaUrl" 
          @click="refreshCaptcha" 
          alt="点击刷新验证码" 
          class="captcha-img"
          :style="{ cursor: isSubmitting ? 'not-allowed' : 'pointer', opacity: isSubmitting ? 0.6 : 1 }"
          :disabled="isSubmitting"
        >
        <input 
          type="text" 
          v-model="form.captcha" 
          required
          @input="clearResult"
          :disabled="isSubmitting"
          :placeholder="form.isHotActivity ? '请输入图中6个目标字符' : '请输入图中4个目标字符'"
          class="form-input captcha-input"
        >
      </div>
      <!-- 新用户二次验证（匹配文档风控要求） -->
      <div class="form-item" v-if="needSmsVerify">
        <label>短信验证码：</label>
        <div class="sms-group">
          <input 
            type="text" 
            v-model="form.smsCode" 
            placeholder="请输入6位短信验证码" 
            required
            :disabled="isSubmitting || !smsBtnAvailable"
            class="form-input"
          >
          <button 
            type="button" 
            class="sms-btn"
            @click="sendSmsVerify"
            :disabled="isSubmitting || !smsBtnAvailable"
          >
            {{ smsBtnText }}
          </button>
        </div>
      </div>
      <!-- 提交按钮 -->
      <button 
        type="submit" 
        class="submit-btn btn btn-primary"
        :disabled="isSubmitting"
      >
        <span v-if="!isSubmitting">提交报名</span>
        <span v-if="isSubmitting" class="loading-spinner">●</span>
        <span v-if="isSubmitting">报名中...</span>
      </button>
    </form>

    <!-- 活动列表弹窗（解决手动输入ID痛点，匹配参考资料1/4） -->
    <teleport to="body">
      <div class="activity-dialog-mask" v-if="showActivityList" @click="showActivityList = false">
        <div class="activity-dialog" @click.stop>
          <div class="dialog-header">
            <h3>活动列表（点击选择）</h3>
            <button class="close-btn" @click="showActivityList = false">×</button>
          </div>
          <div class="dialog-filter">
            <select v-model="selectedActivityType" @change="filterActivities" class="form-select">
              <option value="all">全部类型</option>
              <option value="academic">学术类</option>
              <option value="culture">文体类</option>
              <option value="volunteer">志愿类</option>
            </select>
            <input 
              type="text" 
              placeholder="搜索活动名称" 
              v-model="activitySearchKey" 
              @input="filterActivities"
              class="form-input search-input"
            >
          </div>
          <div class="dialog-content">
            <div class="activity-item" v-for="item in filteredActivities" :key="item.id" @click="selectActivity(item)">
              <div class="activity-tag" :class="item.isHot ? 'hot-tag' : 'normal-tag'">
                {{ item.isHot ? '热门' : '普通' }}
              </div>
              <h4>{{ item.title }}</h4>
              <p class="activity-info">时间：{{ item.startTime }} - {{ item.endTime }}</p>
              <p class="activity-info">名额：{{ item.usedQuota }}/{{ item.totalQuota }}（{{ item.collegeName }}）</p>
              <p class="activity-type">{{ getActivityTypeName(item.type) }}</p>
            </div>
            <div class="empty-tip" v-if="filteredActivities.length === 0">
              暂无匹配活动，请更换筛选条件
            </div>
          </div>
        </div>
      </div>
    </teleport>

    <!-- 报名结果提示（区分成功/失败状态） -->
    <div 
      class="result" 
      v-if="result"
      :class="result.includes('成功') ? 'msg-success' : 'msg-error'"
    >
      {{ result }}
    </div>
    <!-- Axios测试结果（开发环境用，生产环境可删除） -->
    <div class="test-axios" style="margin-top: 20px; color: #666;" v-if="testResult">
      {{ testResult }}
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, reactive, toRaw, watch } from 'vue';
import axios from 'axios';

// 1. 状态定义（新增活动列表相关状态）
const form = reactive({
  userId: '',
  activityId: '',
  collegeId: '',
  captcha: '',
  smsCode: '',
  isHotActivity: false,
  deviceFingerprint: ''
});
const captchaUrl = ref('');
const result = ref('');
const isSubmitting = ref(false);
const needSmsVerify = ref(false);
const smsBtnText = ref('获取验证码');
const smsBtnAvailable = ref(true);
const testResult = ref('');
// 活动列表弹窗相关状态
const showActivityList = ref(false);
const allActivities = ref([]); // 所有活动数据
const filteredActivities = ref([]); // 筛选后活动数据
const selectedActivityType = ref('all'); // 选中的活动类型
const activitySearchKey = ref(''); // 活动搜索关键词

// 2. 初始化：新增活动列表加载（匹配参考资料4“信息整合”需求）
onMounted(async () => {
  generateDeviceFingerprint();
  refreshCaptcha();
  await Promise.all([
    loadActivityList(), // 加载活动列表
    import.meta.env.DEV && testAxiosConnection() // 开发环境测试Axios
  ]);
});

// 3. 核心工具函数（新增活动列表相关逻辑）
/**
 * 生成设备指纹（简化格式，彻底避免特殊字符拦截）
 */
const generateDeviceFingerprint = () => {
  let fingerprint = localStorage.getItem('campus_device_fingerprint');
  if (!fingerprint) {
    // 优化：仅用字母+数字+时间戳，无任何特殊字符
    fingerprint = `dev_${new Date().getTime()}_${Math.floor(Math.random() * 10000)}`;
    localStorage.setItem('campus_device_fingerprint', fingerprint);
  }
  form.deviceFingerprint = fingerprint;
};

/**
 * 刷新验证码（优化：增加加载状态提示）
 */
const refreshCaptcha = async () => {
  captchaUrl.value = 'https://picsum.photos/120/40?random=loading'; // 加载占位图
  try {
    const encodedFingerprint = encodeURIComponent(form.deviceFingerprint);
    const response = await axios.get('/api/risk/captcha', {
      params: {
        isHotActivity: form.isHotActivity,
        deviceFingerprint: encodedFingerprint
      },
      responseType: 'blob'
    });
    // 释放旧URL，避免内存泄漏
    if (captchaUrl.value) URL.revokeObjectURL(captchaUrl.value);
    captchaUrl.value = URL.createObjectURL(response.data);
    form.captcha = '';
    result.value = '';
  } catch (error) {
    result.value = '验证码加载失败，请重试';
    captchaUrl.value = `https://picsum.photos/120/40?random=${Math.random()}`;
    if (import.meta.env.DEV) {
      console.error('验证码请求失败：', error.response?.statusText || error.message);
    }
  }
};

/**
 * 检查活动是否为热门（优化：增加活动信息提示）
 */
const checkActivityHotStatus = async () => {
  if (!form.activityId) return;
  try {
    const response = await axios.get(`/api/activity/check-hot`, {
      params: { activityId: form.activityId }
    });
    form.isHotActivity = response.data.isHot;
    // 新增：显示活动热度提示
    result.value = form.isHotActivity 
      ? '当前为热门活动，验证码难度已升级（6字符）' 
      : '当前为普通活动，验证码难度（4字符）';
    if (form.isHotActivity) {
      refreshCaptcha();
    }
  } catch (error) {
    result.value = '活动状态查询失败，不影响报名但可能影响验证码难度';
  }
};

/**
 * 发送短信验证码（优化：增加手机号验证）
 */
const sendSmsVerify = async () => {
  if (!form.userId) {
    result.value = '请先输入用户ID';
    return;
  }
  // 新增：验证用户ID格式（假设用户ID为8位数字）
  if (!/^\d{8}$/.test(form.userId)) {
    result.value = '用户ID格式错误（需为8位数字）';
    return;
  }

  smsBtnAvailable.value = false;
  smsBtnText.value = '发送中...';
  try {
    const encodedFingerprint = encodeURIComponent(form.deviceFingerprint);
    const response = await axios.post('/api/risk/send-sms', {
      userId: form.userId,
      deviceFingerprint: encodedFingerprint
    });
    // 新增：显示短信发送成功提示
    result.value = `短信已发送至用户绑定手机（尾号${response.data.phoneSuffix}）`;
    
    let count = 60;
    const timer = setInterval(() => {
      count--;
      smsBtnText.value = `${count}秒后重发`;
      if (count <= 0) {
        clearInterval(timer);
        smsBtnText.value = '重新获取';
        smsBtnAvailable.value = true;
      }
    }, 1000);
  } catch (error) {
    result.value = '短信发送失败：' + (error.response?.data || '请稍后重试');
    smsBtnText.value = '重新获取';
    smsBtnAvailable.value = true;
  }
};

/**
 * 加载活动列表（新增：解决手动输入ID痛点，匹配参考资料4）
 */
const loadActivityList = async () => {
  try {
    const response = await axios.get('/api/activity/list');
    allActivities.value = response.data.map(item => ({
      id: item.id,
      title: item.title,
      startTime: formatTime(item.startTime),
      endTime: formatTime(item.endTime),
      totalQuota: item.quota,
      usedQuota: item.usedQuota,
      isHot: item.hotFlag === 1,
      type: item.type,
      collegeName: item.collegeName
    }));
    filteredActivities.value = [...allActivities.value];
  } catch (error) {
    // 降级：使用模拟数据，避免弹窗空白
    allActivities.value = [
      { id: 101, title: 'Java微服务实战讲座', startTime: '2025-01-05 14:00', endTime: '2025-01-05 16:00', totalQuota: 200, usedQuota: 156, isHot: true, type: 'academic', collegeName: '计算机学院' },
      { id: 102, title: '校园歌手大赛', startTime: '2025-01-10 19:00', endTime: '2025-01-10 21:00', totalQuota: 500, usedQuota: 320, isHot: true, type: 'culture', collegeName: '艺术学院' },
      { id: 103, title: '社区志愿服务', startTime: '2025-01-08 09:00', endTime: '2025-01-08 12:00', totalQuota: 100, usedQuota: 45, isHot: false, type: 'volunteer', collegeName: '商学院' }
    ];
    filteredActivities.value = [...allActivities.value];
    if (import.meta.env.DEV) {
      console.warn('活动列表加载失败，使用模拟数据：', error.message);
    }
  }
};

/**
 * 筛选活动（新增：按类型+关键词筛选）
 */
const filterActivities = () => {
  filteredActivities.value = allActivities.value.filter(item => {
    // 类型筛选
    const typeMatch = selectedActivityType === 'all' || item.type === selectedActivityType;
    // 关键词筛选
    const keywordMatch = item.title.toLowerCase().includes(activitySearchKey.toLowerCase());
    return typeMatch && keywordMatch;
  });
};

/**
 * 选择活动（新增：自动填充活动ID+学院ID）
 */
const selectActivity = (item) => {
  form.activityId = item.id;
  form.isHotActivity = item.isHot;
  // 自动填充学院ID（根据活动所属学院）
  const collegeMap = { '计算机学院': 1, '商学院': 2, '文学院': 3, '外国语学院': 4, '艺术学院': 5 };
  form.collegeId = collegeMap[item.collegeName] || '';
  // 刷新验证码（匹配活动热度）
  refreshCaptcha();
  // 关闭弹窗
  showActivityList.value = false;
  // 显示活动信息
  result.value = `已选择活动：${item.title}（${item.isHot ? '热门' : '普通'}，剩余名额：${item.totalQuota - item.usedQuota}）`;
};

/**
 * 工具函数：格式化时间（新增）
 */
const formatTime = (timeStr) => {
  if (!timeStr) return '';
  const date = new Date(timeStr);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
};

/**
 * 工具函数：获取活动类型名称（新增）
 */
const getActivityTypeName = (type) => {
  const typeMap = { 'academic': '学术类', 'culture': '文体类', 'volunteer': '志愿类' };
  return typeMap[type] || '其他';
};

// 4. 核心报名逻辑（优化：增加参数校验+错误处理细化 + 补充响应结果显示）
const submitSignup = async () => {
  // 基础校验
  if (!form.userId || !form.activityId || !form.collegeId || !form.captcha) {
    result.value = '请完善所有必填项';
    return;
  }
  // 新增：用户ID格式校验
  if (!/^\d{8}$/.test(form.userId)) {
    result.value = '用户ID格式错误（需为8位数字）';
    return;
  }
  // 新增：验证码长度校验
  const captchaLength = form.isHotActivity ? 6 : 4;
  if (form.captcha.length !== captchaLength) {
    result.value = `验证码长度错误（需${captchaLength}个字符）`;
    return;
  }
  // 新增：短信验证码校验（若需要）
  if (needSmsVerify.value && !/^\d{6}$/.test(form.smsCode)) {
    result.value = '短信验证码格式错误（需6位数字）';
    return;
  }

  isSubmitting.value = true;
  result.value = '正在提交报名...';

  try {
    const request = axios.create({
      baseURL: '/api',
      timeout: 5000,
      retry: 3,
      retryDelay: (retryCount) => retryCount * 1000
    });

    // 请求拦截器：优化Token携带逻辑
    request.interceptors.request.use(config => {
      const token = localStorage.getItem('campus_token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      config.headers['X-Device-Fingerprint'] = encodeURIComponent(form.deviceFingerprint);
      // 新增：携带用户Agent信息（辅助后端风控）
      config.headers['User-Agent'] = navigator.userAgent;
      return config;
    });

    // 响应拦截器：优化重试逻辑
    request.interceptors.response.use(
      response => response.data,
      async (error) => {
        const config = error.config;
        if (!config.retry || config.retryCount >= config.retry) {
          // 新增：重试失败后记录风控日志
          await axios.post('/api/risk/record', {
            userId: form.userId,
            deviceFingerprint: form.deviceFingerprint,
            riskType: 'REQUEST_RETRY_FAILED',
            riskDesc: `报名请求重试3次失败：${error.message}`
          }).catch(() => {}); // 不阻塞主流程
          return Promise.reject(error);
        }
        config.retryCount = config.retryCount || 0;
        config.retryCount++;
        await new Promise(resolve => setTimeout(resolve, config.retryDelay(config.retryCount)));
        return request(config);
      }
    );

    // 提交报名请求
    const response = await request.post('/signup/submit', {
      userId: form.userId,
      activityId: form.activityId,
      collegeId: form.collegeId,
      captcha: form.captcha,
      smsCode: form.smsCode,
      isHotActivity: form.isHotActivity,
      deviceFingerprint: encodeURIComponent(form.deviceFingerprint),
      // 新增：传递浏览器信息（辅助后端风控）
      browserInfo: navigator.userAgent,
      screenInfo: `${screen.width}x${screen.height}`
    });

    // ========== 核心新增：响应结果处理（显示报名成功/失败） ==========
    if (response.code === 200 || response.success) {
      // 报名成功提示
      result.value = `✅ 报名成功！${response.message || '你的报名信息已提交，可在"我的报名"中查询'}`;
      // 清空表单（可选，根据业务需求）
      form.captcha = '';
      form.smsCode = '';
      needSmsVerify.value = false;
      // 刷新验证码，方便再次报名
      refreshCaptcha();
    } else {
      // 报名失败（后端返回业务错误）
      result.value = `❌ 报名失败：${response.message || '系统处理失败，请稍后重试'}`;
    }

  } catch (error) {
    // 错误处理细化 + 明确的失败提示
    if (error.response?.data) {
      const errMsg = error.response.data;
      if (errMsg.includes('需要短信验证')) {
        needSmsVerify.value = true;
        result.value = '⚠️ 请完成短信验证后重试（新用户/陌生设备报名热门活动要求）';
      } else if (errMsg.includes('名额已用尽')) {
        result.value = `❌ 报名失败：${errMsg}（剩余名额：${error.response.data.remainingQuota || 0}）`;
      } else if (errMsg.includes('已报名')) {
        result.value = `❌ 报名失败：${errMsg}（可在"我的报名"中查询）`;
      } else if (errMsg.includes('验证码错误')) {
        result.value = `❌ 报名失败：${errMsg}（点击验证码图片刷新）`;
        refreshCaptcha(); // 验证码错误时自动刷新
      } else {
        result.value = `❌ 报名失败：${errMsg}`;
      }
    } else if (error.message.includes('timeout')) {
      result.value = '❌ 报名失败：请求超时（已自动重试3次），请检查网络';
    } else {
      result.value = '❌ 报名失败：系统繁忙，请稍后重试（已自动重试3次）';
    }
    refreshCaptcha();

  } finally {
    // 结束提交状态，确保按钮可点击
    isSubmitting.value = false;
  }
};

// 5. 其他工具函数（保留原功能）
const clearResult = () => {
  result.value = '';
};

const testAxiosConnection = async () => {
  try {
    const response = await axios.get('https://jsonplaceholder.typicode.com/todos/1');
    testResult.value = `Axios测试成功：已获取外部接口数据`;
  } catch (error) {
    testResult.value = `Axios测试提示：外部接口访问失败（${error.message}），不影响内部报名接口`;
  }
};

// 6. 监听活动类型变化，自动筛选（新增）
watch([selectedActivityType, activitySearchKey], filterActivities, { immediate: true });
</script>

<style scoped>
/* 基础样式优化 */
.page-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  font-family: "Microsoft YaHei", sans-serif;
}
.signup-container {
  background: #fff;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}
.signup-form {
  margin-top: 25px;
}
.form-item {
  display: flex;
  align-items: center;
  margin-bottom: 18px;
  gap: 12px;
}
.form-item label {
  width: 100px;
  text-align: right;
  font-weight: 500;
  color: #333;
}
.form-input, .form-select {
  flex: 1;
  padding: 10px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
  transition: border-color 0.3s;
}
.form-input:focus, .form-select:focus {
  outline: none;
  border-color: #42b983;
  box-shadow: 0 0 0 2px rgba(66, 185, 131, 0.1);
}
.form-select {
  appearance: none;
  background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23333' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E") right 12px center no-repeat;
  background-size: 16px;
  padding-right: 36px;
}

/* 验证码样式 */
.captcha-group {
  align-items: center;
  display: flex;
}
.captcha-img {
  width: 120px;
  height: 40px;
  margin: 0 10px;
  border-radius: 4px;
  border: 1px solid #eee;
  object-fit: cover;
  transition: opacity 0.3s;
}
.captcha-img:hover {
  opacity: 0.9;
}
.captcha-input {
  flex: none;
  width: 200px;
}

/* 短信验证码样式 */
.sms-group {
  display: flex;
  gap: 10px;
  flex: 1;
}
.sms-btn {
  padding: 10px 16px;
  background-color: #42b983;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  flex-shrink: 0;
  transition: background-color 0.3s;
}
.sms-btn:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

/* 提交按钮样式 */
.submit-btn {
  margin-left: 112px;
  padding: 12px 24px;
  background-color: #42b983;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s;
}
.submit-btn:disabled {
  background-color: #87c9a8;
  cursor: not-allowed;
}
.loading-spinner {
  display: inline-block;
  animation: spin 1s linear infinite;
  margin-right: 8px;
}
@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* 结果提示样式 */
.result {
  margin: 15px 0 0 112px;
  padding: 10px 16px;
  border-radius: 4px;
  font-size: 14px;
  line-height: 1.5;
}
.msg-success {
  background-color: #e6f7ef;
  color: #00864e;
  border: 1px solid #b7ebcc;
}
.msg-error {
  background-color: #fff2f0;
  color: #c53f3f;
  border: 1px solid #ffccc7;
}

/* 活动ID输入组样式 */
.activity-id-group {
  display: flex;
  gap: 10px;
  flex: 1;
}
.select-activity-btn {
  padding: 10px 16px;
  background-color: #f5f5f5;
  color: #333;
  border: 1px solid #ddd;
  border-radius: 4px;
  cursor: pointer;
  flex-shrink: 0;
  transition: background-color 0.3s;
}
.select-activity-btn:hover {
  background-color: #eee;
}

/* 活动列表弹窗样式（新增） */
.activity-dialog-mask {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}
.activity-dialog {
  width: 90%;
  max-width: 600px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  overflow: hidden;
}
.dialog-header {
  padding: 16px 20px;
  border-bottom: 1px solid #eee;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.dialog-header h3 {
  margin: 0;
  font-size: 18px;
  color: #333;
}
.close-btn {
  background: none;
  border: none;
  font-size: 20px;
  color: #999;
  cursor: pointer;
  padding: 0;
  line-height: 1;
}
.close-btn:hover {
  color: #333;
}
.dialog-filter {
  padding: 16px 20px;
  border-bottom: 1px solid #eee;
  display: flex;
  gap: 12px;
}
.search-input {
  flex: 1;
}
.dialog-content {
  max-height: 400px;
  overflow-y: auto;
  padding: 20px;
}
.activity-item {
  padding: 16px;
  border-radius: 4px;
  border: 1px solid #eee;
  margin-bottom: 12px;
  cursor: pointer;
  transition: border-color 0.3s, background-color 0.3s;
  position: relative;
}
.activity-item:hover {
  border-color: #42b983;
  background-color: #f9f9f9;
}
.activity-tag {
  position: absolute;
  top: 16px;
  right: 16px;
  padding: 2px 8px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 500;
}
.hot-tag {
  background-color: #fff2f0;
  color: #c53f3f;
}
.normal-tag {
  background-color: #f0f7ff;
  color: #1890ff;
}
.activity-info {
  margin: 8px 0 0;
  font-size: 14px;
  color: #666;
  line-height: 1.5;
}
.activity-type {
  margin: 8px 0 0;
  font-size: 12px;
  color: #999;
}
.empty-tip {
  text-align: center;
  padding: 40px 0;
  color: #999;
  font-size: 14px;
}

/* 响应式适配（优化移动端体验） */
@media (max-width: 768px) {
  .signup-container {
    padding: 20px 15px;
  }
  .form-item {
    flex-direction: column;
    align-items: flex-start;
    margin-bottom: 15px;
    gap: 8px;
  }
  .form-item label {
    width: 100%;
    text-align: left;
    margin-bottom: 0;
  }
  .captcha-group {
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
  }
  .captcha-img {
    margin: 0 0 8px;
    width: 100%;
  }
  .captcha-input {
    width: 100%;
  }
  .submit-btn {
    margin-left: 0;
    width: 100%;
    margin-top: 10px;
    padding: 12px 0;
  }
  .sms-group {
    width: 100%;
  }
  .activity-id-group {
    width: 100%;
    flex-direction: column;
    gap: 8px;
  }
  .select-activity-btn {
    width: 100%;
  }
  .result {
    margin: 15px 0 0 0;
  }
  .dialog-filter {
    flex-direction: column;
  }
}
</style>