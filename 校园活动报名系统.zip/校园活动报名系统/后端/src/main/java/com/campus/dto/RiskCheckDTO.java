package com.campus.dto;

import lombok.Data;

@Data
public class RiskCheckDTO {
    private Long userId;
    private String deviceFingerprint;
    private String ipAddress;
    private boolean isHotActivity;
}