package com.campus.service; // 包名必须正确，和文件所在目录一致

import com.campus.dto.SignupDTO;
import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.entity.Signup;

// 接口名必须是SignupService，和文件名SignupService.java完全一致
public interface SignupService {
    // 这里可以保留你原来的接口方法，没有的话先空着也可以（先保证编译通过）


    // 核心报名方法
    String signup(SignupDTO signupDTO);

    /**
     * 热门活动报名
     * @param signupDTO 报名请求数据
     * @return 报名结果（如"报名成功"）
     */
    String signupHotActivity(SignupDTO signupDTO);

    /**
     * 普通活动报名
     * @param signupDTO 报名请求数据
     * @return 报名结果（如"报名成功"）
     */
    String signupNormalActivity(SignupDTO signupDTO);


}