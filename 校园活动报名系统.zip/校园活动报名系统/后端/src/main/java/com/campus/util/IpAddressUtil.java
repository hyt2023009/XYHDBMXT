package com.campus.util;

import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSONObject;

/**
 * IP地址工具（查询归属地、判断是否为机房/代理IP）
 */
public class IpAddressUtil {

    // 第三方IP查询接口（示例：ip-api.com）
    private static final String IP_QUERY_URL = "http://ip-api.com/json/";

    /**
     * 判断是否为机房IP
     */
    public static boolean isDataCenterIp(String ip) {
        String result = HttpUtil.get(IP_QUERY_URL + ip);
        JSONObject json = JSONObject.parseObject(result);
        String org = json.getString("org");
        return org != null && (org.contains("Data Center") || org.contains("IDC"));
    }

    /**
     * 判断是否为代理IP
     */
    public static boolean isProxyIp(String ip) {
        String result = HttpUtil.get(IP_QUERY_URL + ip);
        JSONObject json = JSONObject.parseObject(result);
        return json.getBooleanValue("proxy");
    }
}