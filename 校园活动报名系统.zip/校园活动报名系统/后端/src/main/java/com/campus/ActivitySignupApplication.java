package com.campus;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableDiscoveryClient // 注册到Nacos（修正拼写）
@MapperScan("com.campus.mapper") // 扫描Mapper接口（确保mapper包存在）
@EnableKafka // 启用Kafka（需先补pom依赖）
@EnableScheduling // 启用定时任务
public class ActivitySignupApplication {
    public static void main(String[] args) {
        SpringApplication.run(ActivitySignupApplication.class, args);
    }
}