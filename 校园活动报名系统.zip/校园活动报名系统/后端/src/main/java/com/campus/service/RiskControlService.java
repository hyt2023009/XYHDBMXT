package com.campus.service;

import com.campus.dto.RiskCheckDTO;
import com.campus.dto.SignupDTO;
import com.campus.entity.RiskRecord;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 风险控制服务接口
 * 处理报名行为的风险检测、风控规则校验等逻辑
 */
public interface RiskControlService extends IService<RiskRecord> {

    /**
     * 检测报名行为是否存在风险
     * @param signupDTO 报名请求数据
     * @return true=存在风险，false=无风险
     */
    boolean checkSignupRisk(SignupDTO signupDTO);

    /**
     * 记录风险行为
     * @param signupDTO 报名请求数据
     * @param riskType 风险类型（如：设备异常、IP高频、重复报名等）
     * @param riskDesc 风险描述
     */
    void recordRiskBehavior(SignupDTO signupDTO, String riskType, String riskDesc);

    /**
     * 校验用户报名频率是否超限
     * @param userId 用户ID
     * @param activityId 活动ID
     * @return true=超限，false=未超限
     */
    boolean checkSignupFrequency(Long userId, Long activityId);

    /**
     * 校验设备指纹是否存在异常
     * @param deviceFingerprint 设备指纹
     * @param activityId 活动ID
     * @return true=异常，false=正常
     */
    boolean checkDeviceAbnormal(String deviceFingerprint, Long activityId);


    // 新增：与SignupServiceImpl调用一致的方法（返回int类型风险等级）
    int checkRisk(RiskCheckDTO riskCheckDTO);

}