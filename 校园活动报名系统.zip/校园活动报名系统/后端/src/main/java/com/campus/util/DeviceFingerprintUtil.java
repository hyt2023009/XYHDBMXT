package com.campus.util;

import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;

/**
 * 设备指纹生成工具（基于浏览器UA+操作系统+CPU型号）
 */
public class DeviceFingerprintUtil {

    /**
     * 生成设备指纹（MD5加密）
     */
    public static String generateFingerprint(String userAgent, String os, String cpuModel) {
        String source = userAgent + "_" + os + "_" + cpuModel;
        return DigestUtils.md5DigestAsHex(source.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * 校验是否为常用设备（实际项目中需关联用户设备绑定表）
     */
    public static boolean isCommonDevice(Long userId, String deviceFingerprint) {
        // 简化逻辑：模拟常用设备校验（实际需查询数据库）
        return deviceFingerprint.startsWith("123") || deviceFingerprint.startsWith("456");
    }
}