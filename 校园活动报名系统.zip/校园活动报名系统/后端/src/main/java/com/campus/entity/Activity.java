package com.campus.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.util.Date;

/**
 * 活动实体类（类名与DTO对应，添加MyBatis-Plus注解）
 */
@Data
@TableName("activity") // 对应数据库表名
public class Activity {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String title;
    private Date startTime;
    private Date endTime;
    private Integer quota;
    private Integer usedQuota;
    private Integer hotFlag;
    private Date preheatTime;
    private Integer collegeId;
    private Integer cacheVersion;
}