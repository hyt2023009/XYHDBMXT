package com.campus.service.impl;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campus.dto.RiskCheckDTO;
import com.campus.dto.SignupDTO;
import com.campus.dto.SignupMessageDTO;
import com.campus.dto.ActivityDTO;
import com.campus.entity.Activity;
import com.campus.entity.Signup;
import com.campus.mapper.ActivityMapper;
import com.campus.mapper.SignupMapper;
import com.campus.service.ActivityCacheService;
import com.campus.service.RiskControlService;
import com.campus.service.SignupService;
import org.springframework.beans.BeanUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * 报名服务（核心业务逻辑：风控校验→名额扣减→异步写入）
 */
@Service
public class SignupServiceImpl implements SignupService {

    @Resource
    private RiskControlService riskControlService;

    @Resource
    private ActivityCacheService activityCacheService;

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    @Resource
    private KafkaTemplate<String, Object> kafkaTemplate;

    @Resource
    private ActivityMapper activityMapper;

    @Resource
    private SignupMapper signupMapper;

    // Redis分布式锁前缀
    private static final String LOCK_KEY_PREFIX = "signup:lock:";
    // Kafka报名主题
    private static final String SIGNUP_TOPIC = "activity-signup";

    /**
     * 用户报名核心流程
     */
    @Override
    @SentinelResource(
            value = "allActivitySignup", // 全局限流资源名
            blockHandler = "signupBlockHandler", // 限流降级回调
            fallback = "signupFallback" // 异常降级回调
    )
    public String signup(SignupDTO signupDTO) {
        Long userId = signupDTO.getUserId();
        Long activityId = signupDTO.getActivityId();
        String deviceFingerprint = signupDTO.getDeviceFingerprint();
        String ipAddress = signupDTO.getIpAddress();
        String verificationCode = signupDTO.getVerificationCode();

        // 1. 验证码校验（热门活动动态难度）
        if (!verifyCaptcha(activityId, verificationCode)) {
            return "验证码错误，请重新获取";
        }

        // 2. 多维度风控校验
        int riskLevel = riskControlService.checkRisk(buildRiskCheckDTO(signupDTO));
        if (riskLevel == 3) {
            return "您已被列入黑名单，暂无法报名";
        }
        if (riskLevel == 2) {
            return "报名请求存在风险，已被拦截";
        }
        if (riskLevel == 1) {
            return "需完成短信验证后报名（前端跳转短信验证页面）";
        }

        // 3. 获取活动信息（优先缓存）- 修复：先获取DTO，再转换为Entity
        ActivityDTO activityDTO = activityCacheService.getActivityById(activityId);
        Activity activity = convertActivityDTOToEntity(activityDTO);
        if (activity == null || activity.getEndTime().before(new Date())) {
            return "活动不存在或已结束";
        }

        // 4. 分布式锁：防止并发报名
        String lockKey = LOCK_KEY_PREFIX + activityId + ":" + userId;
        boolean locked = redisTemplate.opsForValue().setIfAbsent(lockKey, UUID.randomUUID().toString(), 3, TimeUnit.SECONDS);
        if (!locked) {
            return "操作过频繁，请稍后重试";
        }

        try {
            // 5. 重复报名校验（Redis+数据库双重校验）
            if (isAlreadySignedUp(userId, activityId)) {
                return "您已报名该活动，无需重复提交";
            }

            // 6. 名额扣减（Redis原子操作，避免超卖）
            String quotaKey = "activity:quota:" + activityId;
            Long remainingQuota = redisTemplate.opsForValue().decrement(quotaKey);
            if (remainingQuota == null || remainingQuota < 0) {
                // 名额不足，回滚扣减
                redisTemplate.opsForValue().increment(quotaKey);
                return "活动名额已售罄";
            }

            // 7. 异步写入数据库（Kafka消息）
            kafkaTemplate.send(SIGNUP_TOPIC, buildSignupMessage(signupDTO, activity));

            return "报名提交成功，待确认";
        } finally {
            // 释放分布式锁
            redisTemplate.delete(lockKey);
        }
    }

    /**
     * 热门活动报名（单独限流）
     */
    @Override
    @SentinelResource(
            value = "hotActivitySignup", // 热门活动限流资源名
            blockHandler = "signupBlockHandler"
    )
    public String signupHotActivity(SignupDTO signupDTO) {
        return signup(signupDTO);
    }

    /**
     * 普通活动报名（单独限流）
     */
    @Override
    @SentinelResource(
            value = "normalActivitySignup", // 普通活动限流资源名
            blockHandler = "signupBlockHandler"
    )
    public String signupNormalActivity(SignupDTO signupDTO) {
        return signup(signupDTO);
    }

    /**
     * 限流降级回调
     */
    public String signupBlockHandler(SignupDTO signupDTO, BlockException e) {
        return "当前报名人数过多，请稍后重试";
    }

    /**
     * 异常降级回调
     */
    public String signupFallback(SignupDTO signupDTO, Throwable e) {
        // 异常日志记录（实际项目中用日志框架）
        System.err.println("报名异常：" + e.getMessage());
        return "服务繁忙，请稍后重试";
    }

    /**
     * 验证码校验（模拟动态难度）
     */
    private boolean verifyCaptcha(Long activityId, String verificationCode) {
        // 修复：先获取DTO，再转换为Entity
        ActivityDTO activityDTO = activityCacheService.getActivityById(activityId);
        Activity activity = convertActivityDTOToEntity(activityDTO);
        if (activity == null) {
            return false;
        }
        // 热门活动需6位验证码，普通活动4位
        if (activity.getHotFlag() == 1) {
            return verificationCode != null && verificationCode.length() == 6;
        } else {
            return verificationCode != null && verificationCode.length() == 4;
        }
    }

    /**
     * 重复报名校验
     */
    private boolean isAlreadySignedUp(Long userId, Long activityId) {
        // 1. 先查Redis
        String signupKey = "activity:signup:" + activityId + ":" + userId;
        Boolean isSigned = redisTemplate.hasKey(signupKey);
        if (Boolean.TRUE.equals(isSigned)) {
            return true;
        }

        // 2. Redis未命中，查数据库
        Signup signup = signupMapper.selectOne(
                new LambdaQueryWrapper<Signup>()
                        .eq(Signup::getUserId, userId)
                        .eq(Signup::getActivityId, activityId)
                        .eq(Signup::getStatus, 1) // 1=已报名
        );
        if (signup != null) {
            // 写入Redis缓存（7天过期）
            redisTemplate.opsForValue().set(signupKey, true, 7, TimeUnit.DAYS);
            return true;
        }
        return false;
    }

    /**
     * 构建风控校验DTO
     */
    private RiskCheckDTO buildRiskCheckDTO(SignupDTO signupDTO) {
        RiskCheckDTO riskCheckDTO = new RiskCheckDTO();
        riskCheckDTO.setUserId(signupDTO.getUserId());
        riskCheckDTO.setDeviceFingerprint(signupDTO.getDeviceFingerprint());
        riskCheckDTO.setIpAddress(signupDTO.getIpAddress());
        // 修复：先获取DTO，再转换为Entity
        ActivityDTO activityDTO = activityCacheService.getActivityById(signupDTO.getActivityId());
        Activity activity = convertActivityDTOToEntity(activityDTO);
        riskCheckDTO.setHotActivity(activity != null && activity.getHotFlag() == 1);
        return riskCheckDTO;
    }

    /**
     * 构建Kafka报名消息
     */
    private SignupMessageDTO buildSignupMessage(SignupDTO signupDTO, Activity activity) {
        SignupMessageDTO message = new SignupMessageDTO();
        message.setUserId(signupDTO.getUserId());
        message.setActivityId(signupDTO.getActivityId());
        message.setCollegeId(activity.getCollegeId());
        message.setDeviceFingerprint(signupDTO.getDeviceFingerprint());
        message.setIpAddress(signupDTO.getIpAddress());
        message.setSignupTime(new Date());
        return message;
    }

    /**
     * 工具方法：ActivityDTO（DTO）→ Activity（Entity）属性拷贝
     * 解决类型不兼容问题，不可直接赋值/强转
     */
    private Activity convertActivityDTOToEntity(ActivityDTO activityDTO) {
        // 处理null值，避免空指针异常
        if (activityDTO == null) {
            return null;
        }
        Activity activity = new Activity();
        // Spring BeanUtils自动拷贝同名同类型属性
        BeanUtils.copyProperties(activityDTO, activity);
        return activity;
    }
}