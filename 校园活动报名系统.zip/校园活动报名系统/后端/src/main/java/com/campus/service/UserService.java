package com.campus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.entity.User;

public interface UserService extends IService<User> {
    // 登录方法（生成JWT Token）
    String login(String username, String password);
}