package com.campus.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Random;

/**
 * 风控验证码接口（最终修复版：解决跨域/拦截/图片生成异常）
 */
@RestController
@RequestMapping("/risk")
// 核心修改1：删除局部@CrossOrigin，使用全局跨域配置，避免冲突
public class RiskControlController {

    @GetMapping("/captcha")
    @SuppressWarnings("all") // 临时忽略警告，不影响功能
    public ResponseEntity<byte[]> getCaptcha() {
        // 定义验证码图片固定参数，避免硬编码
        final int IMG_WIDTH = 120;
        final int IMG_HEIGHT = 40;
        final int FONT_SIZE = 20;
        final String FONT_NAME = "SimHei"; // 替换为系统兼容字体，避免Arial找不到

        try {
            // 1. 创建图片缓冲区（解决AWT兼容性问题）
            BufferedImage image = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = image.createGraphics(); // 改用Graphics2D，渲染更稳定

            // 2. 绘制背景（白色）+ 噪点（防识别）
            g2d.setColor(Color.WHITE);
            g2d.fillRect(0, 0, IMG_WIDTH, IMG_HEIGHT);
            // 绘制随机噪点，提升验证码安全性
            Random random = new Random();
            for (int i = 0; i < 50; i++) {
                g2d.setColor(Color.LIGHT_GRAY);
                g2d.fillOval(random.nextInt(IMG_WIDTH), random.nextInt(IMG_HEIGHT), 1, 1);
            }

            // 3. 生成4位随机验证码（补零确保4位）
            String captchaCode = String.format("%06d", random.nextInt(999999));

            // 4. 绘制验证码文字（抗锯齿，居中显示）
            g2d.setColor(Color.BLACK);
            g2d.setFont(new Font(FONT_NAME, Font.BOLD, FONT_SIZE));
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            // 计算文字居中坐标，避免偏移
            FontMetrics metrics = g2d.getFontMetrics();
            int x = (IMG_WIDTH - metrics.stringWidth(captchaCode)) / 2;
            int y = (IMG_HEIGHT - metrics.getHeight()) / 2 + metrics.getAscent();
            g2d.drawString(captchaCode, x, y);

            // 5. 释放资源，避免内存泄漏
            g2d.dispose();

            // 6. 将图片转为字节流（核心：返回PNG格式）
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(image, "PNG", baos);
            byte[] imageBytes = baos.toByteArray();

            // 7. 构建响应头（纯图片流，禁用缓存/嗅探）
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_PNG); // 明确图片类型
            headers.setContentLength(imageBytes.length);
            headers.setCacheControl("no-cache, no-store, must-revalidate"); // 禁止缓存验证码
            headers.setPragma("no-cache"); // 兼容旧浏览器
            headers.set("X-Content-Type-Options", "nosniff"); // 禁用MIME嗅探，避免字符误判

            // 8. 返回图片流+200状态码
            return new ResponseEntity<>(imageBytes, headers, HttpStatus.OK);

        } catch (Exception e) {
            // 打印详细异常日志，便于排查
            System.err.println("验证码生成失败：" + e.getMessage());
            e.printStackTrace();
            // 异常时返回500状态码，前端可捕获提示
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}