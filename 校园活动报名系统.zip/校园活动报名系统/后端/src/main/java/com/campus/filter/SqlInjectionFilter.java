package com.campus.filter;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.regex.Pattern;

/**
 * SQL注入防御过滤器（拦截恶意关键字，修复过时方法问题 + 验证码接口白名单）
 */
@Component
@WebFilter(urlPatterns = "/*", filterName = "sqlInjectionFilter")
public class SqlInjectionFilter implements Filter {

    // SQL注入高危关键字正则（忽略大小写）
    private static final Pattern SQL_INJECT_PATTERN = Pattern.compile(
            "(union|insert|delete|update|drop|alter|truncate|exec|xp_cmdshell|or|and|--|#|;|')",
            Pattern.CASE_INSENSITIVE
    );

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        // 核心新增：验证码接口白名单，直接放行（不执行SQL注入检测）
        String requestURI = httpRequest.getRequestURI();
        if (requestURI.endsWith("/risk/captcha")) {
            chain.doFilter(request, response);
            return;
        }

        // 1. 检查URL参数
        String queryString = httpRequest.getQueryString();
        if (hasSqlInjectKeyword(queryString)) {
            rejectRequest(httpResponse);
            return;
        }

        // 2. 检查请求体（POST请求）
        String requestBody = getRequestBody(httpRequest);
        if (hasSqlInjectKeyword(requestBody)) {
            rejectRequest(httpResponse);
            return;
        }

        // 3. 检查请求头（防止通过Header注入）
        String userAgent = httpRequest.getHeader("User-Agent");
        if (hasSqlInjectKeyword(userAgent)) {
            rejectRequest(httpResponse);
            return;
        }

        // 过滤通过，继续执行
        chain.doFilter(request, response);
    }

    /**
     * 检测字符串中是否包含SQL注入关键字
     */
    private boolean hasSqlInjectKeyword(String content) {
        // 修复：替换过时的 StringUtils.isEmpty(Object)
        if (!StringUtils.hasText(content)) {
            return false;
        }
        return SQL_INJECT_PATTERN.matcher(content).find();
    }

    /**
     * 获取POST请求体内容
     */
    private String getRequestBody(HttpServletRequest request) {
        try {
            return request.getReader().lines().reduce("", (s1, s2) -> s1 + s2);
        } catch (IOException e) {
            return "";
        }
    }

    /**
     * 拒绝恶意请求
     */
    private void rejectRequest(HttpServletResponse response) throws IOException {
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write("{\"code\":400,\"msg\":\"请求包含非法字符，已被拦截\"}");
    }
}