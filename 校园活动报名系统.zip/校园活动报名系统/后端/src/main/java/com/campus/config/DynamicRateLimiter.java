package com.campus.config;

import com.alibaba.csp.sentinel.slots.block.RuleConstant;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRule;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * 基于Sentinel的动态限流配置（按活动热度区分规则）
 */
@Component
public class DynamicRateLimiter {

    /**
     * 项目启动时初始化限流规则
     */
    @PostConstruct
    public void initFlowRules() {
        List<FlowRule> rules = new ArrayList<>();

        // 1. 热门活动限流：2次/分钟（转换为QPS=2/60≈0.033）
        FlowRule hotActivityRule = new FlowRule();
        hotActivityRule.setResource("hotActivitySignup"); // 资源名（需与接口注解对应）
        hotActivityRule.setGrade(RuleConstant.FLOW_GRADE_QPS);
        hotActivityRule.setCount(2.0 / 60);
        hotActivityRule.setLimitApp("default"); // 对所有应用生效
        rules.add(hotActivityRule);

        // 2. 普通活动限流：5次/分钟（QPS=5/60≈0.083）
        FlowRule normalActivityRule = new FlowRule();
        normalActivityRule.setResource("normalActivitySignup");
        normalActivityRule.setGrade(RuleConstant.FLOW_GRADE_QPS);
        normalActivityRule.setCount(5.0 / 60);
        normalActivityRule.setLimitApp("default");
        rules.add(normalActivityRule);

        // 3. 全局限流：1000 QPS（系统最大承载）
        FlowRule globalRule = new FlowRule();
        globalRule.setResource("allActivitySignup");
        globalRule.setGrade(RuleConstant.FLOW_GRADE_QPS);
        globalRule.setCount(1000);
        rules.add(globalRule);

        // 加载规则到Sentinel
        FlowRuleManager.loadRules(rules);
        System.out.println("动态限流规则初始化完成");
    }
}