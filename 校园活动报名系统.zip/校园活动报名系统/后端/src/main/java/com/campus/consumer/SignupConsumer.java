package com.campus.consumer;

import com.campus.dto.SignupMessageDTO;
import com.campus.entity.Signup;
import com.campus.mapper.SignupMapper;
import com.campus.service.ActivityCacheService;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.concurrent.TimeUnit; // 新增：导入TimeUnit类

/**
 * Kafka消费者：异步处理报名记录写入数据库（修复所有编译错误）
 */
@Component
public class SignupConsumer {

    @Resource
    private SignupMapper signupMapper;

    @Resource
    private ActivityCacheService activityCacheService;

    // 修复1：声明并注入RedisTemplate，解决找不到redisTemplate变量
    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    /**
     * 消费报名消息（手动提交offset）
     */
    @KafkaListener(topics = "activity-signup", groupId = "activity-signup-group")
    public void consumeSignupMessage(SignupMessageDTO message, Acknowledgment acknowledgment) {
        try {
            // 1. 写入报名记录到数据库（分库分表由Sharding-JDBC自动路由）
            Signup signup = new Signup();
            signup.setUserId(message.getUserId());
            signup.setActivityId(message.getActivityId());
            signup.setCollegeId(message.getCollegeId());
            signup.setDeviceFingerprint(message.getDeviceFingerprint());
            signup.setIpAddress(message.getIpAddress());
            signup.setSignupTime(message.getSignupTime());
            signup.setStatus(1); // 1=已报名
            signupMapper.insert(signup);

            // 2. 更新Redis中报名状态（7天过期）
            String signupKey = "activity:signup:" + message.getActivityId() + ":" + message.getUserId();
            redisTemplate.opsForValue().set(signupKey, true, 7, TimeUnit.DAYS);

            // 3. 手动提交offset（确保消费成功）
            acknowledgment.acknowledge();
            System.out.println("报名记录写入成功：userId=" + message.getUserId() + ", activityId=" + message.getActivityId());
        } catch (Exception e) {
            // 消费失败会触发Kafka重试机制
            System.err.println("报名记录写入失败：" + e.getMessage());
            throw e;
        }
    }

    /**
     * 消费死信队列消息（人工处理）
     */
    @KafkaListener(topics = "activity-signup-dlq", groupId = "activity-signup-group")
    public void consumeDlqMessage(SignupMessageDTO message) {
        // 记录死信消息（实际项目中可存入数据库或告警）
        System.err.println("死信队列消息：" + message);
    }
}