package com.campus.dto;

import lombok.Data;
import java.util.Date;

@Data
public class SignupMessageDTO {
    private Long userId;
    private Long activityId;
    private Integer collegeId;
    private String deviceFingerprint;
    private String ipAddress;
    private Date signupTime;
}