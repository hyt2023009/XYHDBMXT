package com.campus.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.dto.SignupDTO;
import com.campus.entity.RiskRecord;
import com.campus.mapper.RiskRecordMapper;
import com.campus.mapper.UserMapper;
import com.campus.service.RiskControlService;
import com.campus.util.DeviceFingerprintUtil;
import com.campus.util.IpAddressUtil;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.campus.dto.RiskCheckDTO;

import javax.annotation.Resource;
import java.util.Date;

/**
 * 风控服务（设备指纹+IP归属地+用户行为校验）
 */
@Service
// 继承ServiceImpl，实现MyBatis-Plus的服务基础能力
public class RiskControlServiceImpl extends ServiceImpl<RiskRecordMapper, RiskRecord>
        implements RiskControlService {

    @Resource
    private UserMapper userMapper;

    @Resource
    private RiskRecordMapper riskRecordMapper;

    // 黑名单封禁时长（7天）
    private static final long BLOCK_DURATION = 7 * 24 * 60 * 60 * 1000;


    /**
     * 实现：检测报名行为是否存在风险
     */
    @Override
    public boolean checkSignupRisk(SignupDTO signupDTO) {
        if (signupDTO == null) {
            return true;
        }
        // 频率校验+设备异常校验
        boolean frequencyRisk = checkSignupFrequency(signupDTO.getUserId(), signupDTO.getActivityId());
        boolean deviceRisk = checkDeviceAbnormal(signupDTO.getDeviceFingerprint(), signupDTO.getActivityId());
        return frequencyRisk || deviceRisk;
    }


    /**
     * 实现：记录风险行为
     */
    @Override
    public void recordRiskBehavior(SignupDTO signupDTO, String riskType, String riskDesc) {
        if (signupDTO == null || riskType == null) {
            return;
        }
        RiskRecord record = new RiskRecord();
        record.setUserId(signupDTO.getUserId());
        record.setActivityId(signupDTO.getActivityId());
        record.setRiskType(riskType);
        record.setRiskDesc(riskDesc);
        record.setDeviceFingerprint(signupDTO.getDeviceFingerprint());
        record.setIpAddress(signupDTO.getIpAddress());
        record.setCreateTime(new Date());
        riskRecordMapper.insert(record);
    }


    /**
     * 实现：校验用户报名频率是否超限
     */
    @Override
    public boolean checkSignupFrequency(Long userId, Long activityId) {
        // 示例逻辑：可查询用户1分钟内该活动的报名次数，超过3次则返回true
        return false; // 临时返回未超限
    }


    /**
     * 实现：校验设备指纹是否存在异常
     */
    @Override
    public boolean checkDeviceAbnormal(String deviceFingerprint, Long activityId) {
        // 示例逻辑：可查询该设备10分钟内的报名用户数，超过5个则返回true
        return false; // 临时返回设备正常
    }



    // 新增：实现checkRisk方法，返回风险等级（0=无风险，1=低风险，2=中风险，3=高风险/黑名单）
    @Override
    public int checkRisk(RiskCheckDTO riskCheckDTO) {
        if (riskCheckDTO == null) {
            return 2; // 空参数判定为中风险
        }
        // 模拟风险等级判定逻辑（可根据业务扩展）
        Long userId = riskCheckDTO.getUserId();
        String deviceFingerprint = riskCheckDTO.getDeviceFingerprint();
        boolean isHotActivity = riskCheckDTO.isHotActivity();

        // 黑名单校验（示例：userId为100以内模拟黑名单）
        if (userId != null && userId <= 100) {
            return 3; // 高风险/黑名单
        }
        // 设备异常校验（热门活动更严格）
        if (isHotActivity && checkDeviceAbnormal(deviceFingerprint, null)) {
            return 2; // 中风险
        }
        // 低风险（需短信验证）
        if (isHotActivity && userId != null && userId % 10 == 0) {
            return 1; // 低风险
        }
        return 0; // 无风险
    }
}