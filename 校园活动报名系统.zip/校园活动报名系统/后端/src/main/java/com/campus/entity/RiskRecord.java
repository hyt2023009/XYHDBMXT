package com.campus.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.util.Date;

@Data
@TableName("risk_record")
public class RiskRecord {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long userId;
    private Long activityId; // 活动ID
    private String riskType; // 风险类型
    private String riskDesc; // 风险描述
    private String deviceFingerprint; // 设备指纹
    private String deviceId;
    private String ipAddress;
    private Integer riskLevel;
    private String riskReason;
    private Date blockTime;
    private Date createTime;
}