package com.campus.task;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campus.entity.Activity;
import com.campus.mapper.ActivityMapper;
import com.campus.service.ActivityCacheService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * 缓存预热定时任务（热门活动提前30分钟预热）
 */
@Component
public class CachePreheatTask {

    @Resource
    private ActivityMapper activityMapper;

    @Resource
    private ActivityCacheService activityCacheService;

    /**
     * 每5分钟执行一次（查询未来1小时内开启的热门活动）
     */
    @Scheduled(cron = "0 0/5 * * * ?")
    public void preheatHotActivityCache() {
        Date now = new Date();
        Date nextHour = new Date(now.getTime() + 60 * 60 * 1000); // 未来1小时

        // 查询热门活动（hot_flag=1）且预热时间临近
        List<Activity> hotActivities = activityMapper.selectList(
                new LambdaQueryWrapper<Activity>()
                        .eq(Activity::getHotFlag, 1)
                        .ge(Activity::getStartTime, now)
                        .le(Activity::getStartTime, nextHour)
        );

        // 批量预热缓存
        for (Activity activity : hotActivities) {
            activityCacheService.preheatActivityCache(activity.getId());
        }
    }
}