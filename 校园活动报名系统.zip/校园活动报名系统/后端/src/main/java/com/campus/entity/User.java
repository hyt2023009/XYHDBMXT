package com.campus.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.util.Date;

@Data
@TableName("user")
public class User {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String username;
    private String password;
    private String phoneEncrypt; // 注意：数据库字段是phone_encrypt，MyBatis-Plus会自动转驼峰
    private String emailEncrypt;
    private Date registerTime;
    private Integer collegeId;
}