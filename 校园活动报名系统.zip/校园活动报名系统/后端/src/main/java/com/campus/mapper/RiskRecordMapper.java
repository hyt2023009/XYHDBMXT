package com.campus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.entity.RiskRecord;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RiskRecordMapper extends BaseMapper<RiskRecord> {
}