package com.campus.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campus.entity.Activity;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.campus.dto.ActivityDTO;
import com.campus.mapper.ActivityMapper;
import com.campus.service.ActivityCacheService;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.beans.BeanUtils; // 导入BeanUtils

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

/**
 * 活动缓存服务（Caffeine本地缓存 + Redis分布式缓存，修复类型转换错误）
 */
@Service
public class ActivityCacheServiceImpl implements ActivityCacheService {

    // 一级缓存：Caffeine本地缓存（超热点活动，5分钟过期）
    private final LoadingCache<Long, ActivityDTO> localCache = Caffeine.newBuilder()
            .maximumSize(1000) // 最大缓存1000条
            .expireAfterWrite(5, TimeUnit.MINUTES)
            .build(this::loadActivityFromRedis); // 缓存未命中时从Redis加载

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    @Resource
    private ActivityMapper activityMapper;

    // 缓存Key前缀
    private static final String ACTIVITY_CACHE_KEY = "activity:info:";

    /**
     * 根据活动ID查询缓存（优先本地缓存，再Redis，最后数据库）
     */
    @Override
    public ActivityDTO getActivityById(Long activityId) {
        // 1. 查本地缓存
        ActivityDTO activityDTO = localCache.get(activityId);
        if (activityDTO != null && activityDTO.getId() != null) {
            return activityDTO;
        }

        // 2. 本地缓存未命中，查Redis
        activityDTO = loadActivityFromRedis(activityId);
        if (activityDTO != null && activityDTO.getId() != null) {
            return activityDTO;
        }

        // 3. Redis未命中，查数据库（返回Activity实体）
        Activity activity = activityMapper.selectById(activityId);
        // 修复：将Activity实体转换为ActivityDTO
        activityDTO = convertActivityToDTO(activity);

        if (activityDTO != null && activityDTO.getId() != null) {
            // 写入Redis（1小时过期）
            redisTemplate.opsForValue().set(
                    ACTIVITY_CACHE_KEY + activityId,
                    activityDTO,
                    1,
                    TimeUnit.HOURS
            );
            // 写入本地缓存
            localCache.put(activityId, activityDTO);
        } else {
            // 缓存空值（10分钟过期，防止缓存穿透）
            ActivityDTO emptyDTO = new ActivityDTO();
            redisTemplate.opsForValue().set(
                    ACTIVITY_CACHE_KEY + activityId,
                    emptyDTO,
                    10,
                    TimeUnit.MINUTES
            );
            activityDTO = emptyDTO;
        }
        return activityDTO;
    }

    /**
     * 从Redis加载活动信息
     */
    private ActivityDTO loadActivityFromRedis(Long activityId) {
        Object obj = redisTemplate.opsForValue().get(ACTIVITY_CACHE_KEY + activityId);
        // 安全转换：先判断类型再强转，避免类型转换异常
        if (obj instanceof ActivityDTO) {
            return (ActivityDTO) obj;
        }
        return null;
    }

    /**
     * 缓存预热：手动将活动信息写入Redis（配合定时任务使用）
     */
    @Override
    public void preheatActivityCache(Long activityId) {
        // 查数据库返回Activity实体
        Activity activity = activityMapper.selectById(activityId);
        // 修复：转换为ActivityDTO
        ActivityDTO activityDTO = convertActivityToDTO(activity);

        if (activityDTO != null && activityDTO.getId() != null) {
            redisTemplate.opsForValue().set(
                    ACTIVITY_CACHE_KEY + activityId,
                    activityDTO,
                    1,
                    TimeUnit.HOURS
            );
            localCache.put(activityId, activityDTO);
            System.out.println("活动缓存预热完成：activityId=" + activityId);
        }
    }

    /**
     * 删除缓存（活动信息更新时调用）
     */
    @Override
    public void deleteActivityCache(Long activityId) {
        redisTemplate.delete(ACTIVITY_CACHE_KEY + activityId);
        localCache.invalidate(activityId);
        System.out.println("活动缓存删除完成：activityId=" + activityId);
    }

    /**
     * 工具方法：Activity（Entity）→ ActivityDTO（DTO）属性拷贝
     * 解决类型不兼容问题，不可直接赋值/强转
     */
    private ActivityDTO convertActivityToDTO(Activity activity) {
        // 处理null值，避免空指针异常
        if (activity == null) {
            return null;
        }
        ActivityDTO activityDTO = new ActivityDTO();
        // Spring BeanUtils自动拷贝同名同类型属性
        BeanUtils.copyProperties(activity, activityDTO);
        return activityDTO;
    }
}