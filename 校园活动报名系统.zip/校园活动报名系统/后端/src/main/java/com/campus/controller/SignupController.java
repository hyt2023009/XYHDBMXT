package com.campus.controller;

import com.campus.dto.SignupDTO;
import com.campus.service.SignupService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/signup")
public class SignupController {

    @Resource
    private SignupService signupService;

    /**
     * 热门活动报名接口（适配最新SignupDTO字段）
     */
    @PostMapping("/hot")
    public Map<String, Object> signupHot(@Valid @RequestBody SignupDTO signupDTO) {
        Map<String, Object> result = new HashMap<>();
        try {
            // 调用Service层热门活动报名逻辑（匹配DTO字段）
            String serviceMsg = signupService.signupHotActivity(signupDTO);
            // 成功响应（适配前端判断逻辑）
            result.put("code", 200);
            result.put("message", "热门活动报名成功：" + serviceMsg);
            result.put("success", true);
            result.put("signupNo", "BN" + System.currentTimeMillis()); // 报名编号（可选）
        } catch (IllegalArgumentException e) {
            // 业务异常（如验证码错误、名额不足等）
            result.put("code", 400);
            result.put("message", e.getMessage());
            result.put("success", false);
        } catch (Exception e) {
            // 系统异常
            e.printStackTrace();
            result.put("code", 500);
            result.put("message", "热门活动报名失败：系统异常，请稍后重试");
            result.put("success", false);
        }
        return result;
    }

    /**
     * 普通活动报名接口（适配最新SignupDTO字段）
     */
    @PostMapping("/normal")
    public Map<String, Object> signupNormal(@Valid @RequestBody SignupDTO signupDTO) {
        Map<String, Object> result = new HashMap<>();
        try {
            // 调用Service层普通活动报名逻辑（匹配DTO字段）
            String serviceMsg = signupService.signupNormalActivity(signupDTO);
            // 成功响应
            result.put("code", 200);
            result.put("message", "普通活动报名成功：" + serviceMsg);
            result.put("success", true);
            result.put("signupNo", "BN" + System.currentTimeMillis());
        } catch (IllegalArgumentException e) {
            // 业务异常
            result.put("code", 400);
            result.put("message", e.getMessage());
            result.put("success", false);
        } catch (Exception e) {
            // 系统异常
            e.printStackTrace();
            result.put("code", 500);
            result.put("message", "普通活动报名失败：系统异常，请稍后重试");
            result.put("success", false);
        }
        return result;
    }

    /**
     * 统一报名提交接口（自动区分热门/普通，前端推荐调用）
     * 注：若需区分活动类型，可在Service层通过activityId查询活动类型，无需DTO传isHotActivity
     */
    @PostMapping("/submit")
    public Map<String, Object> submitSignup(@Valid @RequestBody SignupDTO signupDTO) {
        Map<String, Object> result = new HashMap<>();
        try {
            String serviceMsg;
            // 方式1：Service层通过activityId查询活动是否为热门（推荐，无需前端传参）
            // boolean isHot = signupService.checkActivityIsHot(signupDTO.getActivityId());
            // 方式2：若仍需前端传，需在DTO中新增isHotActivity字段（Long/Boolean类型）
            // 此处先适配现有DTO，默认走普通活动（可根据实际业务调整）
            serviceMsg = signupService.signupNormalActivity(signupDTO);

            // 成功响应
            result.put("code", 200);
            result.put("message", "报名成功：" + serviceMsg);
            result.put("success", true);
            result.put("signupNo", "BN" + System.currentTimeMillis());
        } catch (IllegalArgumentException e) {
            result.put("code", 400);
            result.put("message", e.getMessage());
            result.put("success", false);
        } catch (Exception e) {
            e.printStackTrace();
            result.put("code", 500);
            result.put("message", "报名失败：系统异常，请稍后重试");
            result.put("success", false);
        }
        return result;
    }
}