package com.campus.dto;

import lombok.Data;
import javax.validation.constraints.NotNull;

@Data
public class SignupDTO {
    @NotNull(message = "用户ID不能为空")
    private Long userId;

    @NotNull(message = "活动ID不能为空")
    private Long activityId;

    @NotNull(message = "设备指纹不能为空")
    private String deviceFingerprint;

    @NotNull(message = "IP地址不能为空")
    private String ipAddress;

    @NotNull(message = "验证码不能为空")
    private String verificationCode;
}