package com.campus.dto;

import lombok.Data;
import java.util.Date;

/**
 * 活动DTO（与实体类类名统一，避免“应在名为Activity.java中声明”报错）
 */
@Data
public class ActivityDTO {
    private Long id;
    private String title;
    private Date startTime;
    private Date endTime;
    private Integer quota;
    private Integer usedQuota;
    private Integer hotFlag;
    private Date preheatTime;
    private Integer collegeId;
    private Integer cacheVersion;
}