package com.campus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.entity.Activity;

public interface ActivityService extends IService<Activity> {
}