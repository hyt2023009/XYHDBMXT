package com.campus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.entity.Signup;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SignupMapper extends BaseMapper<Signup> {
}