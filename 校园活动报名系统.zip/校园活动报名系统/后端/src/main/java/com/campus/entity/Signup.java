package com.campus.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.util.Date;

@Data
@TableName("signup") // Sharding-JDBC会自动路由到分表
public class Signup {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long userId;
    private Long activityId;
    private Date signupTime;
    private Integer status;
    private String deviceFingerprint;
    private String ipAddress;
    private Integer collegeId;
}