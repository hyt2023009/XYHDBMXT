package com.campus.util;

import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.symmetric.AES;

/**
 * AES-256加密工具
 */
public class EncryptUtil {
    private static final String AES_KEY = "your_aes_secret_key_32bytes"; // 32位密钥（实际从Nacos获取）
    private static final AES aes = SecureUtil.aes(AES_KEY.getBytes());

    // 加密
    public static String encrypt(String content) {
        return aes.encryptHex(content);
    }

    // 解密
    public static String decrypt(String content) {
        return aes.decryptStr(content);
    }
}