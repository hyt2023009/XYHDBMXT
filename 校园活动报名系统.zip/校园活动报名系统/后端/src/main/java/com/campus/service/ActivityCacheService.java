package com.campus.service;

import com.campus.entity.Activity;
import com.campus.dto.ActivityDTO; // 导入DTO
/**
 * 活动缓存服务接口（补充getActivityById方法）
 */

public interface ActivityCacheService {

    // 新增：与SignupServiceImpl调用一致的方法
    ActivityDTO getActivityById(Long activityId);


    // 新增：预热缓存的方法
    void preheatActivityCache(Long activityId);

    // 新增：与实现类deleteActivityCache方法签名完全一致
    void deleteActivityCache(Long activityId); // 关键：确保方法名、参数、返回值一致


}